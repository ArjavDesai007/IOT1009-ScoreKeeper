package com.app.arjav.score.keeper;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Its for radio buttons point
    private int POINT = 1;

    // Tracks the score for Team ABC
    private int scoreTeamABC = 0;
    // Tracks the score for Team XYZ
    private int scoreTeamXYZ = 0;

    // TextView that displays Team A score
    private TextView mTeamABCScoreView;
    // TextView that displays Team B score
    private TextView mTeamXYZScoreView;

    //Plus button for team XYZ
    private TextView plusButtonXYZ;
    //Minus button for team XYZ
    private TextView minusButtonXYZ;

    //Plus button for team ABC
    private TextView plusButtonABC;
    //Minus button for team ABC
    private TextView minusButtonABC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Team ABC score view
        mTeamABCScoreView = findViewById(R.id.team_a_score);
        //Team XYZ score view
        mTeamXYZScoreView = findViewById(R.id.team_b_score);


        //Plus button for team ABC
        plusButtonABC = findViewById(R.id.plus_1_team_abc);
        //Minus button for team ABC
        minusButtonABC = findViewById(R.id.minus_1_team_abc);


        //Plus button for team XYZ
        plusButtonXYZ = findViewById(R.id.plus_1_team_xyz);
        //Minus button for team XYZ
        minusButtonXYZ = findViewById(R.id.minus_1_team_xyz);



        // Radio group for multi point selection
        RadioGroup rg = (RadioGroup) findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener((group, checkedId) -> {
            switch(checkedId){
                case R.id.point1:
                     POINT = 1;
                     updateButton(POINT);
                    // Its increase point 1 from radio button
                    break;
                case R.id.point2:
                     POINT = 2;
                    updateButton(POINT);
                    // Its increase point 2 from radio button
                    break;
                case R.id.point3:
                     POINT = 3;
                    updateButton(POINT);
                    // Its increase point 3 from radio button
                    break;
            }
        });

    }

    private void updateButton(int point) {

        // Update both team plus/minus button's according to selected point's of radio button
        plusButtonABC.setText("+"+point+" POINT");
        minusButtonABC.setText("-"+point+" POINT");

        plusButtonXYZ.setText("+"+point+" POINT");
        minusButtonXYZ.setText("-"+point+" POINT");

    }


    public void addPoint(View v) {

        int id = v.getId();
        switch (id) {
            case R.id.plus_1_team_abc:
                // Its plus selected point from team ABC's score
                scoreTeamABC = scoreTeamABC + POINT;
                display(mTeamABCScoreView, scoreTeamABC);
                break;
            case R.id.minus_1_team_abc:
                // Increase the score for Team A by 2 points.
                if (scoreTeamABC == 0){
                    showMessage("Team ABC Score is already zero");
                } else if (scoreTeamABC < POINT){
                    showMessage("Team ABC's Total score is less than selected minus point");
                } else {

                    // Its minus selected point from team ABC's score
                    scoreTeamABC = scoreTeamABC - POINT;
                    display(mTeamABCScoreView, scoreTeamABC);
                }

                break;
            case R.id.plus_1_team_xyz:
                // Its plus selected point from team XYZ's score
                scoreTeamXYZ = scoreTeamXYZ + POINT;
                display(mTeamXYZScoreView, scoreTeamXYZ);
                break;
            case R.id.minus_1_team_xyz:
                //Increase the score for Team B by 2 points.
                if (scoreTeamXYZ == 0){
                    showMessage("Team XYZ Score is already zero");
                } else if (scoreTeamXYZ < POINT){
                    showMessage("Team XYZ's Total score is less than selected minus point");
                } else {

                    // Its minus selected point from team XYZ's score
                    scoreTeamXYZ = scoreTeamXYZ - POINT;
                    display(mTeamXYZScoreView, scoreTeamXYZ);
                }

                break;
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }


    public void resetScore(View v) {
        // Its reset both teams score and display zero in score view
        scoreTeamABC = 0;
        scoreTeamXYZ = 0;
        display(mTeamABCScoreView, scoreTeamABC);
        display(mTeamXYZScoreView, scoreTeamXYZ);
    }

    private void display(TextView scoreView, int score) {
        scoreView.setText(String.valueOf(score));
    }

}